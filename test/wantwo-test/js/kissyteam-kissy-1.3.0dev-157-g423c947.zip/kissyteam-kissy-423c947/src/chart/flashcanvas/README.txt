bug fix
https://groups.google.com/forum/#!searchin/flashcanvas/qipbbn/flashcanvas/3M6OezskYlU/uY4HcqY4_x8J


Well then, would you try this latest version of FlashCanvas Pro?
http://download.revulo.com/Canvas/FlashCanvasPro-20110719.zip
The bug described in the following page may be the cause of your problem.
http://code.google.com/p/flashcanvas/source/detail?r=206
<?php
header("Content-Type:text/html");
echo $_GET["callback"]
?>('haha')
 


# Underscore

Underscore 是一个小巧的 JavaScript 语言增强库，提供了 Collection, Array, Function,
Object 等便捷、强大的操作方法。可以与 jQuery, Backbone 等组件一起使用。

---


## 使用说明

- 官方文档：<http://documentcloud.github.com/underscore/>


## 更新

当 underscore 组件有新版本发布，需要更新时，只需运行以下命令就好：

```
$ node update.js
```

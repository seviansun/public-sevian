
# Moment.js

A lightweight (4.3k) javascript date library for parsing, manipulating, and formatting dates.

---


## 使用说明

- 官方文档：<http://momentjs.com/docs/>


## 更新

当 moment 组件有新版本发布，需要更新时，只需运行以下命令就好：

```
$ node update.js
```

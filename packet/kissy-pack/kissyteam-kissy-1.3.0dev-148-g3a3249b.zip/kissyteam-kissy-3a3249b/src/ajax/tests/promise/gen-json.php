<?php
header("Content-Type:application/json;");
?>
{"x":<?php echo  $_GET['x']; ?>}
KISSY.add("chart/colors", function(S){
    var P = S.namespace("Chart"),
        colors = [
         { c : "#00b0f0" },
         { c : "#FF4037" },
         { c : "#39B54A" },
         { c : "#FEF56F" },
         { c : "#c821ac" },
         { c : "#D1EB53" }
    ];
    P.colors = colors;
});

/**
 * @fileOverview calendar
 */
KISSY.add("calendar", function (S, C, Page, Time, Date) {
    S.Date = C.Date = Date;
    S.Calendar = C;
    return C;
}, {
    requires:["calendar/base", "calendar/page", "calendar/time", "calendar/date"]
});

/**
 左莫 2011-12-28：
 1.新增配置参数：
 disabled:null, //禁止点击的日期数组[new Date(),new Date(2011,11,26)]
 range:    null,//已选择的时间段{start:null,end:null}
 align:{
 points:['bl','tl'],
 offset:[0,0]
 },//对其方式
 notLimited:    false,// 是否出现不限的按钮
 rangLinkage //多个日历是否联动
 2.新增加功能
 -加入了"年"的前进后退
 -加入了不限按钮，在点击之后触发“select”事件，参数为null,
 -Date.parse方法新增对"2011-12-27"字符串的处理
 3.bug修复
 -修复最小最大日期限制后31号始终可点击的BUG
 4.样式的调整
 -美化了
 **/